import TodoListTemplate from './TodoListTemplate';

function App() {
  return (
    <>
      <TodoListTemplate />
    </>
  );
}

export default App;
